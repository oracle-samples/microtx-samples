from __future__ import annotations
import logging
import os
import time
from typing import Optional

from conductor.client.configuration.settings.authentication_settings import AuthenticationSettings


class Configuration:
    AUTH_TOKEN = None

    def __init__(
            self,
            base_url: Optional[str] = None,
            debug: bool = False,
            authentication_settings: AuthenticationSettings = None,
            server_api_url: Optional[str] = None,
            auth_token_ttl_min: int = 45,
            token_url: Optional[str] = None,
            key: Optional[str] = None,
            secret: Optional[str] = None,
            token: Optional[str] = None
    ):
        if server_api_url is not None:
            self.host = server_api_url
        elif base_url is not None:
            self.host = base_url + "/api"
        else:
            self.host = os.getenv("CONDUCTOR_SERVER_URL")

        if self.host is None or self.host == "":
            self.host = "http://localhost:9010/workflow-server/api"

        self.temp_folder_path = None
        self.__ui_host = os.getenv("CONDUCTOR_UI_SERVER_URL")
        if self.__ui_host is None:
            self.__ui_host = self.host.replace("9010/workflow-server/api", "5001")

        # If token_url is provided explicitly in constructor, set it
        if token_url is not None:
            self.token_url = token_url

        if authentication_settings is not None:
            self.authentication_settings = authentication_settings
            # Override provided AuthenticationSettings with explicit constructor values if given
            if key is not None:
                self.authentication_settings.key_id = key
            if secret is not None:
                self.authentication_settings.key_secret = secret
        else:
            # Merge explicit key/secret with environment fallbacks
            eff_key = key if key is not None else os.getenv("CONDUCTOR_AUTH_KEY")
            eff_secret = secret if secret is not None else os.getenv("CONDUCTOR_AUTH_SECRET")
            if eff_key is not None and eff_secret is not None:
                self.authentication_settings = AuthenticationSettings(key_id=eff_key, key_secret=eff_secret)
            else:
                self.authentication_settings = None


        # Debug switch
        self.debug = debug
        # Log format
        self.logger_format = "%(asctime)s %(name)-12s %(levelname)-8s %(message)s"

        # SSL/TLS verification
        # Set this to false to skip verifying SSL certificate when calling API
        # from https server.
        self.verify_ssl = True
        # Set this to customize the certificate file to verify the peer.
        self.ssl_ca_cert = None
        # client certificate file
        self.cert_file = None
        # client key file
        self.key_file = None
        # Set this to True/False to enable/disable SSL hostname verification.
        self.assert_hostname = None

        # Proxy URL
        self.proxy = None
        # Safe chars for path_param
        self.safe_chars_for_path_param = ""

        # Provide an alterative to requests.Session() for HTTP connection.
        self.http_connection = None

        # not updated yet
        self.token_update_time = 0
        self.auth_token_ttl_msec = auth_token_ttl_min * 60 * 1000

        # Initialize token if provided via constructor
        if token is not None:
            self.update_token(token)

    @property
    def debug(self):
        """Debug status

        :param value: The debug status, True or False.
        :type: bool
        """
        return self.__debug

    @debug.setter
    def debug(self, value):
        """Debug status

        :param value: The debug status, True or False.
        :type: bool
        """
        self.__debug = value
        if self.__debug:
            self.__log_level = logging.DEBUG
        else:
            self.__log_level = logging.INFO

    @property
    def logger_format(self):
        """The logger format.

        The logger_formatter will be updated when sets logger_format.

        :param value: The format string.
        :type: str
        """
        return self.__logger_format

    @logger_format.setter
    def logger_format(self, value):
        """The logger format.

        The logger_formatter will be updated when sets logger_format.

        :param value: The format string.
        :type: str
        """
        self.__logger_format = value

    @property
    def log_level(self):
        """The log level.

        The log_level will be updated when sets logger_format.

        :param value: The format string.
        :type: str
        """
        return self.__log_level

    @property
    def ui_host(self):
        """

        The log_level will be updated when sets logger_format.

        :param value: The format string.
        :type: str
        """
        return self.__ui_host

    @property
    def token_url(self) -> Optional[str]:
        """
        OAuth2 token endpoint URL used to fetch service tokens.
        Falls back to the TOKEN_URL environment variable if not explicitly set.
        """
        try:
            return self.__token_url
        except AttributeError:
            env_val = os.getenv("TOKEN_URL")
            self.__token_url = env_val
            return self.__token_url

    @token_url.setter
    def token_url(self, value: Optional[str]) -> None:
        self.__token_url = value

    @property
    def key(self) -> Optional[str]:
        """
        Access key id used for authentication.
        Proxies to authentication_settings.key_id when available.
        """
        if getattr(self, "authentication_settings", None):
            return getattr(self.authentication_settings, "key_id", None)
        return None

    @key.setter
    def key(self, value: Optional[str]) -> None:
        if getattr(self, "authentication_settings", None) is None:
            # Initialize settings if missing, attempt to preserve secret from env if available
            existing_secret = os.getenv("SECRET") or os.getenv("CONDUCTOR_AUTH_SECRET")
            self.authentication_settings = AuthenticationSettings(key_id=value, key_secret=existing_secret)
        else:
            self.authentication_settings.key_id = value

    @property
    def secret(self) -> Optional[str]:
        """
        Access key secret used for authentication.
        Proxies to authentication_settings.key_secret when available.
        """
        if getattr(self, "authentication_settings", None):
            return getattr(self.authentication_settings, "key_secret", None)
        return None

    @secret.setter
    def secret(self, value: Optional[str]) -> None:
        if getattr(self, "authentication_settings", None) is None:
            existing_key = os.getenv("KEY") or os.getenv("CONDUCTOR_AUTH_KEY")
            self.authentication_settings = AuthenticationSettings(key_id=existing_key, key_secret=value)
        else:
            self.authentication_settings.key_secret = value

    def apply_logging_config(self, log_format : Optional[str] = None, level = None):
        if log_format is None:
            log_format = self.logger_format
        if level is None:
            level = self.__log_level
        logging.basicConfig(
            format=log_format,
            level=level
        )

    @staticmethod
    def get_logging_formatted_name(name):
        return f"[{os.getpid()}] {name}"

    def update_token(self, token: str) -> None:
        self.AUTH_TOKEN = token
        self.token_update_time = round(time.time() * 1000)
