import base64
import datetime
import json
import logging
import mimetypes
import os
import re
import tempfile
import time
import uuid
from typing import Dict, Optional, Any, Tuple

import requests
import six
import urllib3
from requests.structures import CaseInsensitiveDict
from six.moves.urllib.parse import quote

import conductor.client.http.models as http_models
from conductor.client.configuration.configuration import Configuration
from conductor.client.http import rest
from conductor.client.http.rest import AuthorizationException
from conductor.client.http.thread import AwaitableThread

logger = logging.getLogger(
    Configuration.get_logging_formatted_name(__name__)
)

# ---------------------------------------------------------------------------
# Security helpers
# ---------------------------------------------------------------------------

# Cached service token (client_credentials mode)
_SERVICE_TOKEN: Optional[str] = None
_SERVICE_TOKEN_EXPIRES_AT: Optional[int] = None  # epoch seconds


def _now() -> int:
    return int(time.time())


def _is_security_enabled() -> bool:
    """
    Security is enabled unless CONDUCTOR_SECURITY_ENABLED is explicitly "false".
    """
    return os.getenv("CONDUCTOR_SECURITY_ENABLED", "true").lower() != "false"


def _base64url_decode(data: str) -> bytes:
    """Decode base64url (without requiring padding)."""
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def _get_exp_from_jwt(token: str) -> Optional[int]:
    """
    Extract 'exp' claim from a JWT without verifying the signature.

    Returns:
        exp as epoch seconds, or None if not present / invalid.
    """
    try:
        parts = token.split(".")
        if len(parts) < 2:
            return None
        payload_b64 = parts[1]
        payload_bytes = _base64url_decode(payload_b64)
        payload = json.loads(payload_bytes.decode("utf-8"))
        exp = payload.get("exp")
        if isinstance(exp, (int, float)):
            return int(exp)
    except Exception as exc:
        logger.debug("Failed to parse exp from JWT: %s", exc)
    return None


def _is_jwt_usable(token: str, leeway: int = 60) -> bool:
    """
    A JWT is usable if:
        - it has no 'exp' (we treat it as non-expiring), or
        - now < exp - leeway
    """
    exp = _get_exp_from_jwt(token)
    if exp is None:
        # No expiry claim; assume caller manages lifetime
        return True

    now = _now()
    return now < exp - leeway


def _get_user_jwt_token(leeway: int = 60) -> Optional[str]:
    """
    Use CONDUCTOR_USER_JWT from environment as long as it is still usable.

    - Reads from os.getenv("CONDUCTOR_USER_JWT") for every call.
    - If missing or expired (based on 'exp' and leeway) => returns None.
    """
    user_jwt = os.getenv("CONDUCTOR_USER_JWT")
    if not user_jwt:
        return None

    if _is_jwt_usable(user_jwt, leeway=leeway):
        return user_jwt

    exp = _get_exp_from_jwt(user_jwt)
    logger.info(
        "CONDUCTOR_USER_JWT appears expired or about to expire. now=%s exp=%s (leeway=%s)",
        _now(),
        exp,
        leeway,
    )
    return None


def _get_provided_jwt_token(config: Optional[Configuration], leeway: int = 60) -> Optional[str]:
    """
    Return a user-provided JWT from environment (CONDUCTOR_USER_JWT) or from Configuration.AUTH_TOKEN
    if available and still usable (not expired considering leeway).
    Preference: environment first, then configuration.
    """
    # Environment first
    env_token = os.getenv("CONDUCTOR_USER_JWT")
    if env_token and _is_jwt_usable(env_token, leeway=leeway):
        return env_token
    if env_token and not _is_jwt_usable(env_token, leeway=leeway):
        exp = _get_exp_from_jwt(env_token)
        logger.info(
            "CONDUCTOR_USER_JWT appears expired or about to expire. now=%s exp=%s (leeway=%s)",
            _now(),
            exp,
            leeway,
        )

    # Configuration fallback
    cfg_token = getattr(config, "AUTH_TOKEN", None) if config else None
    if cfg_token and _is_jwt_usable(cfg_token, leeway=leeway):
        return cfg_token
    if cfg_token and not _is_jwt_usable(cfg_token, leeway=leeway):
        exp = _get_exp_from_jwt(cfg_token)
        logger.info(
            "Configuration token appears expired or about to expire. now=%s exp=%s (leeway=%s)",
            _now(),
            exp,
            leeway,
        )

    return None


def _resolve_service_credentials(config: Optional[Configuration]) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    # Environment first
    env_token_url = os.getenv("TOKEN_URL")
    env_key = os.getenv("KEY") or os.getenv("CONDUCTOR_AUTH_KEY")
    env_secret = os.getenv("SECRET") or os.getenv("CONDUCTOR_AUTH_SECRET")

    # Configuration fallback
    cfg_token_url = getattr(config, "token_url", None) if config else None
    cfg_key = getattr(config, "key", None) if config else None
    cfg_secret = getattr(config, "secret", None) if config else None

    token_url = env_token_url or cfg_token_url
    key = env_key or cfg_key
    secret = env_secret or cfg_secret
    return token_url, key, secret


def _get_service_token(
    token_url: Optional[str] = None,
    key: Optional[str] = None,
    secret: Optional[str] = None,
    timeout: int = 5,
    leeway: int = 60,
    force_refresh: bool = False,
) -> Optional[str]:
    """
    Fetch / cache a service token using OAuth2 client_credentials:

        POST TOKEN_URL
          Content-Type: application/x-www-form-urlencoded
          grant_type=client_credentials
          client_id=<key>
          client_secret=<secret>

    Response JSON:
        {"access_token": "...", "expires_in": 3600}

    - Uses module-level cache _SERVICE_TOKEN / _SERVICE_TOKEN_EXPIRES_AT.
    """
    global _SERVICE_TOKEN, _SERVICE_TOKEN_EXPIRES_AT

    token_url = token_url or os.getenv("TOKEN_URL")
    key = key or os.getenv("KEY") or os.getenv("CONDUCTOR_AUTH_KEY")
    secret = secret or os.getenv("SECRET") or os.getenv("CONDUCTOR_AUTH_SECRET")

    if not token_url:
        logger.error("TOKEN_URL is not set. Cannot fetch service token.")
        return None
    if not key or not secret:
        logger.error(
            "Client credentials (KEY/CONDUCTOR_AUTH_KEY, "
            "SECRET/CONDUCTOR_AUTH_SECRET) are not fully set. "
            "Cannot fetch service token."
        )
        return None

    now = _now()

    # Use cached token if still valid and not forced to refresh
    if (
        _SERVICE_TOKEN
        and _SERVICE_TOKEN_EXPIRES_AT
        and not force_refresh
    ):
        if now < _SERVICE_TOKEN_EXPIRES_AT - leeway:
            logger.debug(
                "Using cached service token. now=%s exp=%s",
                now,
                _SERVICE_TOKEN_EXPIRES_AT,
            )
            return _SERVICE_TOKEN

    # Fetch new token from TOKEN_URL
    try:
        logger.info("Requesting new service token")
        response = requests.post(
            token_url,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type": "client_credentials",
                "client_id": key,
                "client_secret": secret,
            },
            timeout=timeout,
        )
        response.raise_for_status()
        payload = response.json()

        access_token = payload.get("access_token")
        expires_in = payload.get("expires_in")

        if not access_token:
            # Avoid logging full payload as it may contain sensitive information
            safe_keys = list(payload.keys()) if isinstance(payload, dict) else "n/a"
            logger.error("Token endpoint response: missing access_token")
            return None

        _SERVICE_TOKEN = access_token

        if isinstance(expires_in, (int, float)):
            _SERVICE_TOKEN_EXPIRES_AT = now + int(expires_in)
        else:
            # If no expires_in, try to infer from JWT exp; otherwise no explicit TTL
            exp = _get_exp_from_jwt(access_token)
            _SERVICE_TOKEN_EXPIRES_AT = exp

        logger.debug(
            "Obtained new service token; expires_in=%s, expires_at=%s",
            expires_in,
            _SERVICE_TOKEN_EXPIRES_AT,
        )
        return _SERVICE_TOKEN

    except requests.RequestException as exc:
        status = getattr(getattr(exc, "response", None), "status_code", "n/a")
        logger.error("Failed to fetch service token")
        return None
    except Exception as exc:
        logger.error(
            "Unexpected error while fetching service token (%s)",
            exc.__class__.__name__,
        )
        return None


def _get_bearer_token(config: Optional[Configuration] = None) -> Optional[str]:
    """
    Central bearer token resolution, implementing your rules:

    If CONDUCTOR_SECURITY_ENABLED is false:
      -> return None (no Authorization header).

    If CONDUCTOR_SECURITY_ENABLED is true AND
    TOKEN_URL + client_id + client_secret are provided:
      -> get service token via client_credentials (use until usable).

    Else if CONDUCTOR_SECURITY_ENABLED is true AND ONLY token is provided
    (CONDUCTOR_USER_JWT):
      -> use it until it is usable; when not usable, log error asking user
         to refresh token.
    """
    if not _is_security_enabled():
        return None

    # 1) Service mode: TOKEN_URL + KEY/SECRET present
    token_url, key, secret = _resolve_service_credentials(config)

    if token_url and key and secret:
        # Pure service mode: ignore CONDUCTOR_USER_JWT in this case
        return _get_service_token(token_url=token_url, key=key, secret=secret)

    # 2) Provided JWT (env or configuration)
    user_token = _get_provided_jwt_token(config)
    if user_token:
        return user_token

    # 3) Security enabled, but no usable token
    cfg_token_present = bool(getattr(config, "AUTH_TOKEN", None)) if config else False
    if os.getenv("CONDUCTOR_USER_JWT") or cfg_token_present:
        # Token is present but expired/unusable
        logger.error(
            "CONDUCTOR_SECURITY_ENABLED is true and a user token was provided via environment "
            "(CONDUCTOR_USER_JWT) or Configuration(token=...), but it is expired or not usable. "
            "Please refresh or provide a valid token."
        )
    else:
        logger.error(
            "CONDUCTOR_SECURITY_ENABLED is true but neither "
            "TOKEN_URL + KEY/SECRET nor a user token (CONDUCTOR_USER_JWT or Configuration(token=...)) are configured. "
            "No Authorization header will be sent."
        )

    return None


# ---------------------------------------------------------------------------
# MicroTxApiClient
# ---------------------------------------------------------------------------


class MicroTxApiClient(object):
    PRIMITIVE_TYPES = (float, bool, bytes, six.text_type) + six.integer_types
    NATIVE_TYPES_MAPPING = {
        "int": int,
        "long": int if six.PY3 else long,  # noqa: F821
        "float": float,
        "str": str,
        "bool": bool,
        "date": datetime.date,
        "datetime": datetime.datetime,
        "object": object,
    }

    def __init__(
        self,
        configuration=None,
        header_name=None,
        header_value=None,
        cookie=None,
        metrics_collector=None,
    ):
        if configuration is None:
            configuration = Configuration()
        self.configuration = configuration
        self.rest_client = rest.RESTClientObject(
            connection=configuration.http_connection
        )
        self.default_headers = self.__get_default_headers(
            header_name, header_value
        )
        self.cookie = cookie

        # Metrics collector for API request tracking
        self.metrics_collector = metrics_collector

    # ---------------------------------------------------------------------
    # Core request flow
    # ---------------------------------------------------------------------

    def __call_api(
        self,
        resource_path,
        method,
        path_params=None,
        query_params=None,
        header_params=None,
        body=None,
        post_params=None,
        files=None,
        response_type=None,
        auth_settings=None,
        _return_http_data_only=None,
        collection_formats=None,
        _preload_content=True,
        _request_timeout=None,
    ):
        """
        Internal, single-attempt call. No automatic token refresh here;
        token resolution happens inside __get_authentication_headers() using
        _get_bearer_token() logic.
        """
        return self.__call_api_no_retry(
            resource_path=resource_path,
            method=method,
            path_params=path_params,
            query_params=query_params,
            header_params=header_params,
            body=body,
            post_params=post_params,
            files=files,
            response_type=response_type,
            auth_settings=auth_settings,
            _return_http_data_only=_return_http_data_only,
            collection_formats=collection_formats,
            _preload_content=_preload_content,
            _request_timeout=_request_timeout,
        )

    def __call_api_no_retry(
        self,
        resource_path,
        method,
        path_params=None,
        query_params=None,
        header_params=None,
        body=None,
        post_params=None,
        files=None,
        response_type=None,
        auth_settings=None,
        _return_http_data_only=None,
        collection_formats=None,
        _preload_content=True,
        _request_timeout=None,
    ):
        config = self.configuration

        # header parameters
        header_params = header_params or {}
        header_params.update(self.default_headers)
        if self.cookie:
            header_params["Cookie"] = self.cookie

        if header_params:
            header_params = self.sanitize_for_serialization(header_params)
            header_params = dict(
                self.parameters_to_tuples(header_params, collection_formats)
            )

        # path parameters
        if path_params:
            path_params = self.sanitize_for_serialization(path_params)
            path_params = self.parameters_to_tuples(
                path_params, collection_formats
            )
            for k, v in path_params:
                # specified safe chars, encode everything
                resource_path = resource_path.replace(
                    "{%s}" % k,
                    quote(str(v), safe=config.safe_chars_for_path_param),
                )

        # query parameters
        if query_params:
            query_params = self.sanitize_for_serialization(query_params)
            query_params = self.parameters_to_tuples(
                query_params, collection_formats
            )

        # post parameters
        if post_params or files:
            post_params = self.prepare_post_parameters(post_params, files)
            post_params = self.sanitize_for_serialization(post_params)
            post_params = self.parameters_to_tuples(
                post_params, collection_formats
            )

        # auth headers (Bearer token based on env / TOKEN_URL)
        auth_headers = self.__get_authentication_headers()
        self.update_params_for_auth(header_params, query_params, auth_headers)

        # body
        if body:
            body = self.sanitize_for_serialization(body)

        # request url
        url = self.configuration.host + resource_path

        # perform request and return response
        response_data = self.request(
            method,
            url,
            query_params=query_params,
            headers=header_params,
            post_params=post_params,
            body=body,
            _preload_content=_preload_content,
            _request_timeout=_request_timeout,
        )
        self.last_response = response_data

        return_data = response_data
        if _preload_content:
            # deserialize response data
            if response_type:
                return_data = self.deserialize(response_data, response_type)
            else:
                return_data = None

        if _return_http_data_only:
            return return_data
        else:
            return (
                return_data,
                response_data.status,
                response_data.getheaders(),
            )

    # ---------------------------------------------------------------------
    # Public call_api wrapper (sync / async)
    # ---------------------------------------------------------------------

    def call_api(
        self,
        resource_path,
        method,
        path_params=None,
        query_params=None,
        header_params=None,
        body=None,
        post_params=None,
        files=None,
        response_type=None,
        auth_settings=None,
        async_req=None,
        _return_http_data_only=None,
        collection_formats=None,
        _preload_content=True,
        _request_timeout=None,
    ):
        """
        Makes the HTTP request (synchronous) and returns deserialized data.

        To make an async request, set the async_req parameter.
        """
        if not async_req:
            return self.__call_api(
                resource_path,
                method,
                path_params,
                query_params,
                header_params,
                body,
                post_params,
                files,
                response_type,
                auth_settings,
                _return_http_data_only,
                collection_formats,
                _preload_content,
                _request_timeout,
            )

        thread = AwaitableThread(
            target=self.__call_api,
            args=(
                resource_path,
                method,
                path_params,
                query_params,
                header_params,
                body,
                post_params,
                files,
                response_type,
                auth_settings,
                _return_http_data_only,
                collection_formats,
                _preload_content,
                _request_timeout,
            ),
        )
        thread.start()
        return thread

    # ---------------------------------------------------------------------
    # Low-level HTTP request
    # ---------------------------------------------------------------------

    def request(
        self,
        method,
        url,
        query_params=None,
        headers=None,
        post_params=None,
        body=None,
        _preload_content=True,
        _request_timeout=None,
    ):
        """Makes the HTTP request using RESTClient."""

        # Extract URI path from URL (remove query params and domain)
        try:
            from urllib.parse import urlparse

            parsed_url = urlparse(url)
            uri = parsed_url.path or url
        except Exception:
            uri = url

        # Start timing
        start_time = time.time()
        status_code = "unknown"

        try:
            if method == "GET":
                response = self.rest_client.GET(
                    url,
                    query_params=query_params,
                    _preload_content=_preload_content,
                    _request_timeout=_request_timeout,
                    headers=headers,
                )
            elif method == "HEAD":
                response = self.rest_client.HEAD(
                    url,
                    query_params=query_params,
                    _preload_content=_preload_content,
                    _request_timeout=_request_timeout,
                    headers=headers,
                )
            elif method == "OPTIONS":
                response = self.rest_client.OPTIONS(
                    url,
                    query_params=query_params,
                    headers=headers,
                    post_params=post_params,
                    _preload_content=_preload_content,
                    _request_timeout=_request_timeout,
                    body=body,
                )
            elif method == "POST":
                response = self.rest_client.POST(
                    url,
                    query_params=query_params,
                    headers=headers,
                    post_params=post_params,
                    _preload_content=_preload_content,
                    _request_timeout=_request_timeout,
                    body=body,
                )
            elif method == "PUT":
                response = self.rest_client.PUT(
                    url,
                    query_params=query_params,
                    headers=headers,
                    post_params=post_params,
                    _preload_content=_preload_content,
                    _request_timeout=_request_timeout,
                    body=body,
                )
            elif method == "PATCH":
                response = self.rest_client.PATCH(
                    url,
                    query_params=query_params,
                    headers=headers,
                    post_params=post_params,
                    _preload_content=_preload_content,
                    _request_timeout=_request_timeout,
                    body=body,
                )
            elif method == "DELETE":
                response = self.rest_client.DELETE(
                    url,
                    query_params=query_params,
                    headers=headers,
                    _preload_content=_preload_content,
                    _request_timeout=_request_timeout,
                    body=body,
                )
            else:
                raise ValueError(
                    "http method must be `GET`, `HEAD`, `OPTIONS`, "
                    "`POST`, `PATCH`, `PUT` or `DELETE`."
                )

            # Extract status code from response
            status_code = (
                str(response.status)
                if hasattr(response, "status")
                else "200"
            )

            # Record metrics
            if self.metrics_collector is not None:
                elapsed_time = time.time() - start_time
                self.metrics_collector.record_api_request_time(
                    method=method,
                    uri=uri,
                    status=status_code,
                    time_spent=elapsed_time,
                )

            return response

        except AuthorizationException as e:
            # Explicitly handle authorization errors
            status_code = str(getattr(e, "status", getattr(e, "code", "401")))
            if self.metrics_collector is not None:
                elapsed_time = time.time() - start_time
                self.metrics_collector.record_api_request_time(
                    method=method, uri=uri, status=status_code, time_spent=elapsed_time
                )
            raise
        except rest.ApiException as e:
            # Explicitly handle API errors from REST layer
            status_code = str(getattr(e, "status", getattr(e, "code", "error")))
            if self.metrics_collector is not None:
                elapsed_time = time.time() - start_time
                self.metrics_collector.record_api_request_time(
                    method=method, uri=uri, status=status_code, time_spent=elapsed_time
                )
            raise
        except requests.exceptions.Timeout as e:
            # Convert requests timeout into a consistent ApiException
            status_code = "timeout"
            if self.metrics_collector is not None:
                elapsed_time = time.time() - start_time
                self.metrics_collector.record_api_request_time(
                    method=method, uri=uri, status=status_code, time_spent=elapsed_time
                )
            logger.error("Request timed out for %s %s: %s", method, url, e)
            raise rest.ApiException(status=0, reason=f"Timeout while calling {method} {url}: {e}")
        except requests.exceptions.ConnectionError as e:
            # Convert connection issues into a consistent ApiException
            status_code = "connection_error"
            if self.metrics_collector is not None:
                elapsed_time = time.time() - start_time
                self.metrics_collector.record_api_request_time(
                    method=method, uri=uri, status=status_code, time_spent=elapsed_time
                )
            logger.error("Connection error for %s %s: %s", method, url, e)
            raise rest.ApiException(status=0, reason=f"Connection error while calling {method} {url}: {e}")
        except requests.exceptions.RequestException as e:
            # Catch-all for other requests-related errors
            status_code = "request_error"
            if self.metrics_collector is not None:
                elapsed_time = time.time() - start_time
                self.metrics_collector.record_api_request_time(
                    method=method, uri=uri, status=status_code, time_spent=elapsed_time
                )
            logger.error("Request error for %s %s: %s", method, url, e)
            raise rest.ApiException(status=0, reason=f"Request error while calling {method} {url}: {e}")
        except Exception as e:
            # Any other unexpected error; log with traceback and wrap consistently
            if hasattr(e, "status"):
                status_code = str(e.status)
            elif hasattr(e, "code"):
                status_code = str(e.code)
            else:
                status_code = "error"

            if self.metrics_collector is not None:
                elapsed_time = time.time() - start_time
                self.metrics_collector.record_api_request_time(
                    method=method, uri=uri, status=status_code, time_spent=elapsed_time
                )

            logger.exception("Unexpected error during %s %s", method, url)
            raise rest.ApiException(status=0, reason=f"Unexpected error during {method} {url}: {type(e).__name__}: {e}")

    # ---------------------------------------------------------------------
    # Serialization / deserialization helpers
    # ---------------------------------------------------------------------

    def sanitize_for_serialization(self, obj):
        """
        Builds a JSON POST object.
        """
        if obj is None:
            return None
        elif isinstance(obj, bytes):
            # Handle bytes: try UTF-8 decode, fallback to base64 for binary data
            try:
                return obj.decode("utf-8")
            except UnicodeDecodeError:
                # Binary data - encode as base64 string
                return base64.b64encode(obj).decode("ascii")
        elif isinstance(obj, self.PRIMITIVE_TYPES):
            return obj
        elif isinstance(obj, list):
            return [self.sanitize_for_serialization(sub_obj) for sub_obj in obj]
        elif isinstance(obj, tuple):
            return tuple(
                self.sanitize_for_serialization(sub_obj) for sub_obj in obj
            )
        elif isinstance(obj, (datetime.datetime, datetime.date)):
            return obj.iso8601()
        elif isinstance(obj, uuid.UUID):
            # needed for compatibility with Python 3.7
            return str(obj)  # Convert UUID to string
        if isinstance(obj, dict) or isinstance(obj, CaseInsensitiveDict):
            obj_dict = obj
        else:
            if hasattr(obj, "attribute_map") and hasattr(
                obj, "swagger_types"
            ):
                obj_dict = {
                    obj.attribute_map[attr]: getattr(obj, attr)
                    for attr, _ in six.iteritems(obj.swagger_types)
                    if getattr(obj, attr) is not None
                }
            else:
                try:
                    obj_dict = {
                        name: getattr(obj, name)
                        for name in vars(obj)
                        if getattr(obj, name) is not None
                    }
                except TypeError:
                    # Fallback to string representation.
                    return str(obj)
        return {
            key: self.sanitize_for_serialization(val)
            for key, val in six.iteritems(obj_dict)
        }

    def deserialize(self, response, response_type):
        """
        Deserializes response into an object.
        """
        # handle file downloading
        if response_type == "file":
            return self.__deserialize_file(response)

        # fetch data from response object
        try:
            data = response.resp.json()
        except Exception:
            data = response.resp.text

        try:
            return self.__deserialize(data, response_type)
        except ValueError as e:
            logger.error(
                f"failed to deserialize data {data} into class {response_type}, "
                f"reason: {e}"
            )
            return None

    def deserialize_class(self, data, klass):
        return self.__deserialize(data, klass)

    def __deserialize(self, data, klass):
        """
        Deserializes dict, list, str into an object.
        """
        if data is None:
            return None

        if isinstance(klass, str):
            if klass.startswith("list["):
                sub_kls = re.match(r"list\[(.*)\]", klass).group(1)
                return [
                    self.__deserialize(sub_data, sub_kls)
                    for sub_data in data
                ]

            if klass.startswith("set["):
                sub_kls = re.match(r"set\[(.*)\]", klass).group(1)
                return set(
                    self.__deserialize(sub_data, sub_kls)
                    for sub_data in data
                )

            if klass.startswith("dict("):
                sub_kls = re.match(r"dict\(([^,]*), (.*)\)", klass).group(2)
                return {
                    k: self.__deserialize(v, sub_kls)
                    for k, v in six.iteritems(data)
                }

            # convert str to class
            if klass in self.NATIVE_TYPES_MAPPING:
                klass = self.NATIVE_TYPES_MAPPING[klass]
            else:
                klass = getattr(http_models, klass)

        if klass in self.PRIMITIVE_TYPES:
            return self.__deserialize_primitive(data, klass)
        elif klass is object:
            return self.__deserialize_object(data)
        elif klass == datetime.date:
            return self.__deserialize_date(data)
        elif klass == datetime.datetime:
            return self.__deserialize_datatime(data)
        else:
            return self.__deserialize_model(data, klass)

    def __deserialize_file(self, response):
        """
        Deserializes body to file.
        """
        fd, path = tempfile.mkstemp(
            dir=self.configuration.temp_folder_path
        )
        os.close(fd)
        os.remove(path)

        content_disposition = response.getheader("Content-Disposition")
        if content_disposition:
            filename = re.search(
                r'filename=[\'"]?([^\'"\s]+)[\'"]?',
                content_disposition,
            ).group(1)
            path = os.path.join(os.path.dirname(path), filename)

        response_data = response.data
        with open(path, "wb") as f:
            if isinstance(response_data, str):
                response_data = response_data.encode("utf-8")
            f.write(response_data)

        return path

    def __deserialize_primitive(self, data, klass):
        """
        Deserializes string to primitive type.
        """
        try:
            if klass is str and isinstance(data, bytes):
                return self.__deserialize_bytes_to_str(data)
            return klass(data)
        except UnicodeEncodeError:
            return six.text_type(data)
        except TypeError:
            return data

    def __deserialize_bytes_to_str(self, data):
        return data.decode("utf-8")

    def __deserialize_object(self, value):
        """
        Return original value.
        """
        return value

    def __deserialize_date(self, string):
        """
        Deserializes string to date.
        """
        try:
            from dateutil.parser import parse

            return parse(string).date()
        except ImportError:
            return string
        except ValueError:
            raise rest.ApiException(
                status=0,
                reason="Failed to parse `{0}` as date object".format(string),
            )

    def __deserialize_datatime(self, string):
        """
        Deserializes string to datetime (iso8601).
        """
        try:
            from dateutil.parser import parse

            return parse(string)
        except ImportError:
            return string
        except ValueError:
            raise rest.ApiException(
                status=0,
                reason=(
                    "Failed to parse `{0}` as datetime object".format(string)
                ),
            )

    def __hasattr(self, object, name):
        return name in object.__class__.__dict__

    def __deserialize_model(self, data, klass):
        """
        Deserializes list or dict to model.
        """
        if not klass.swagger_types and not self.__hasattr(
            klass, "get_real_child_model"
        ):
            return data

        kwargs = {}
        if klass.swagger_types is not None:
            for attr, attr_type in six.iteritems(klass.swagger_types):
                if (
                    data is not None
                    and klass.attribute_map[attr] in data
                    and isinstance(data, (list, dict))
                ):
                    value = data[klass.attribute_map[attr]]
                    kwargs[attr] = self.__deserialize(value, attr_type)

        instance = klass(**kwargs)

        if (
            isinstance(instance, dict)
            and klass.swagger_types is not None
            and isinstance(data, dict)
        ):
            for key, value in data.items():
                if key not in klass.swagger_types:
                    instance[key] = value

        if self.__hasattr(instance, "get_real_child_model"):
            klass_name = instance.get_real_child_model(data)
            if klass_name:
                instance = self.__deserialize(data, klass_name)

        return instance

    # ---------------------------------------------------------------------
    # Params & headers helpers
    # ---------------------------------------------------------------------

    def parameters_to_tuples(self, params, collection_formats):
        """
        Get parameters as list of tuples, formatting collections.
        """
        new_params = []

        if collection_formats is None:
            collection_formats = {}

        for k, v in (
            six.iteritems(params) if isinstance(params, dict) else params
        ):
            if k in collection_formats:
                collection_format = collection_formats[k]
                if collection_format == "multi":
                    new_params.extend((k, value) for value in v)
                else:
                    if collection_format == "ssv":
                        delimiter = " "
                    elif collection_format == "tsv":
                        delimiter = "\t"
                    elif collection_format == "pipes":
                        delimiter = "|"
                    else:
                        delimiter = ","
                    new_params.append(
                        (k, delimiter.join(str(value) for value in v))
                    )
            else:
                new_params.append((k, v))

        return new_params

    def prepare_post_parameters(self, post_params=None, files=None):
        """
        Builds form parameters for post operations.
        """
        params = []
        if post_params:
            params = post_params

        if files:
            for k, v in six.iteritems(files):
                if not v:
                    continue
                file_names = v if isinstance(v, list) else [v]
                for n in file_names:
                    with open(n, "rb") as f:
                        filename = os.path.basename(f.name)
                        filedata = f.read()
                        mimetype = (
                            mimetypes.guess_type(filename)[0]
                            or "application/octet-stream"
                        )
                        params.append(
                            (k, (filename, filedata, mimetype))
                        )

        return params

    def select_header_accept(self, accepts):
        """
        Returns `Accept` header.
        """
        if not accepts:
            return

        accepts = [x.lower() for x in accepts]

        if "application/json" in accepts:
            return "application/json"
        else:
            return ", ".join(accepts)

    def select_header_content_type(self, content_types):
        """
        Returns `Content-Type` header.
        """
        if not content_types:
            return "application/json"

        content_types = [x.lower() for x in content_types]

        if (
            "application/json" in content_types
            or "*/*" in content_types
        ):
            return "application/json"
        else:
            return content_types[0]

    def update_params_for_auth(self, headers, querys, auth_settings):
        """
        Updates header and query params based on auth_settings dict:
            {"header": {...}, "query": {...}}
        """
        if not auth_settings:
            return

        if "header" in auth_settings:
            for key, value in auth_settings["header"].items():
                headers[key] = value

        if "query" in auth_settings:
            for key, value in auth_settings["query"].items():
                querys[key] = value

    # ---------------------------------------------------------------------
    # Auth header builder
    # ---------------------------------------------------------------------

    def get_authentication_headers(self):
        return self.__get_authentication_headers()

    def __get_authentication_headers(self):
        """
        Build auth headers according to the simplified rules:

        - If CONDUCTOR_SECURITY_ENABLED == "false":
            -> no headers.

        - If CONDUCTOR_SECURITY_ENABLED == "true" AND
          TOKEN_URL + client_id + client_secret are provided:
            -> Authorization: Bearer <service_token> (client_credentials).

        - Else if a user token is provided via environment (CONDUCTOR_USER_JWT) or Configuration(token=...):
            -> Authorization: Bearer <token> while usable.
            -> If expired/missing, log an error asking the user to refresh or provide a valid token
               and return no headers.
        """
        token = _get_bearer_token(self.configuration)
        if not token:
            return None

        return {"header": {"Authorization": f"Bearer {token}"}}

    # ---------------------------------------------------------------------
    # Default headers
    # ---------------------------------------------------------------------

    def __get_default_headers(
        self, header_name: str, header_value: Any
    ) -> Dict[str, Any]:
        headers: Dict[str, Any] = {
            "Accept-Encoding": "gzip",
        }

        if header_name is not None:
            headers[header_name] = header_value

        parsed = urllib3.util.parse_url(self.configuration.host)
        if parsed.auth is not None:
            encrypted_headers = urllib3.util.make_headers(
                basic_auth=parsed.auth
            )
            for key, value in encrypted_headers.items():
                headers[key] = value

        return headers
